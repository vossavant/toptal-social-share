jQuery(function($) {
	var elements = $('.ttss-sticky');
	Stickyfill.add(elements);
});